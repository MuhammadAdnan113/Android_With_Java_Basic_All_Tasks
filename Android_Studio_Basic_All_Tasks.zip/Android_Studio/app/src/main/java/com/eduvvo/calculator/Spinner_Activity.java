package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class Spinner_Activity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    Spinner spin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner);

        spin=findViewById(R.id.spin);

        String[] clist = {"Pakistan","Afghanistan","India","Bangladesh"};



        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Spinner_Activity.this,
                android.R.layout.simple_spinner_dropdown_item, clist);
        spin.setAdapter(adapter);
        spin.setOnItemSelectedListener(this);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(Spinner_Activity.this, spin.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}