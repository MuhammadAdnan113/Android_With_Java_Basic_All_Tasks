package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.LinearLayout;

public class RecyclerView_Activity extends AppCompatActivity {

    RecyclerView recyclerview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);

        recyclerview= findViewById(R.id.recyclerview);

        String[] data= new String[]{"Adnan","Ali","Ahmad","Kashif","Junaid"};

        MyRecyclerViewAdapter adapter = new MyRecyclerViewAdapter(data);
        recyclerview.setLayoutManager(new LinearLayoutManager(this));
        recyclerview.setAdapter(adapter);
    }
}