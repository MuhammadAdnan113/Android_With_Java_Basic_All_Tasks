package com.eduvvo.calculator;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class Custom_Spinner extends BaseAdapter {
    LayoutInflater inflater;
    ArrayList<FlagInfo> fdetail = new ArrayList<FlagInfo>();
    Context cntx;
    public Custom_Spinner(ArrayList<FlagInfo> fdetail, Context cntx) {
        this.fdetail = fdetail;
        this.cntx = cntx;
        inflater= LayoutInflater.from(cntx);
    }

    @Override
    public int getCount() {
        return fdetail.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView=inflater.inflate(R.layout.activity_custom_stinner,null);
        TextView tv = convertView.findViewById(R.id.txxcustspin);
        ImageView img = convertView.findViewById(R.id.custspinimg);
        FlagInfo f = fdetail.get(position);
        tv.setText(f.getCountry_name());
        img.setImageResource(f.getFlag_id());

        return convertView;
    }
}
