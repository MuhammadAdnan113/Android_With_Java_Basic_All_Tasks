package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class Radio_Activity extends AppCompatActivity {

    TextView lblname;
    RadioButton rdbtnmale,rdbtnfemale,rdbtntrans;
    EditText etxtname1;
    Button btndisplay;
    String gender="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radio);

        lblname=findViewById(R.id.lblname);

        rdbtnmale=findViewById(R.id.rdbtnmale);
        rdbtnfemale=findViewById(R.id.rdbtnfemale);
        rdbtntrans=findViewById(R.id.rdbtntrans);

        etxtname1=findViewById(R.id.etxtname1);

        btndisplay=findViewById(R.id.btndisplay);

        rdbtnmale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rdbtnmale.isChecked())
                {
                    gender="Mr. ";
                }
                else{
                    gender="";
                }
            }
        }); // end Male

        rdbtnfemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rdbtnfemale.isChecked())
                {
                    gender="Ms. ";
                }
                else{
                    gender="";
                }
            }
        }); // end Female

        rdbtntrans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rdbtntrans.isChecked())
                {
                    gender="Hi ";
                }
            }
        }); // end Female

    btndisplay.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            if (!(etxtname1.getText().toString().isEmpty())) {
              String name = etxtname1.getText().toString();
              lblname.setText(gender + name);
            }
            else{
                lblname.setText(gender + "Enter Name");
            }
          }
        }); // end Display
    }
}