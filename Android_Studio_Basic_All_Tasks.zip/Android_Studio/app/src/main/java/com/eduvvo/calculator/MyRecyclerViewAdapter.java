package com.eduvvo.calculator;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.zip.Inflater;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewHolder> {
    String[] datasource;

    public MyRecyclerViewAdapter(String[] datasource) {
        this.datasource = datasource;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v =inflater.inflate(R.layout.my_recycler_view,parent,false);
        return new RecyclerViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        holder.tv.setText(datasource[position]);
    }

    @Override
    public int getItemCount() {
        return datasource.length;
    }
}
