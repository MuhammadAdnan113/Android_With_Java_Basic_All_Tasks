package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Spinner;

import java.util.ArrayList;

public class Custom_Stinner extends AppCompatActivity {

    ArrayList<FlagInfo> dataresource= new ArrayList<FlagInfo>();
    Spinner spinner;
    FlagInfo f = new FlagInfo();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_stinner);

        f.setCountry_name("Pakistan");
        f.setFlag_id(R.drawable.adnan);
        dataresource.add(f);

        Custom_Spinner adapter = new Custom_Spinner(dataresource,Custom_Stinner.this);

    }
}