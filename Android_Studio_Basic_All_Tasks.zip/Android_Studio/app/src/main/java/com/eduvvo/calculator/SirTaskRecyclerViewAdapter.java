package com.eduvvo.calculator;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SirTaskRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewHolder>{
    ArrayList<Employee> datasource1;

    public SirTaskRecyclerViewAdapter(ArrayList<Employee> datasource) {
        this.datasource1 = datasource;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v =inflater.inflate(R.layout.sirtask_recycler_view,parent,false);
        return new RecyclerViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        holder.tv.setText((CharSequence) datasource1.get(position));
    }

    @Override
    public int getItemCount() {
        return datasource1.size();
    }
}
