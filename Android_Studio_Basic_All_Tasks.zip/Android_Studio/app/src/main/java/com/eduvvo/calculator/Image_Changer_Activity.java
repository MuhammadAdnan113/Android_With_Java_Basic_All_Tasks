package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.Random;

public class Image_Changer_Activity extends AppCompatActivity {

    Button btnchangeimg;
    ImageView changeimg;
    ArrayList<Integer> img_path = new ArrayList<Integer>();

    int cnt =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_changer);

        btnchangeimg=findViewById(R.id.btnchangeimg);
        changeimg=findViewById(R.id.changeimg);

        img_path.add((R.drawable.adnan));
        img_path.add((R.drawable.gift));
        img_path.add((R.drawable.gender));
        img_path.add((R.drawable.study));
        img_path.add((R.drawable.university));
        img_path.add((R.drawable.teacher));
        int count = img_path.size();

        btnchangeimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i=cnt;i<=cnt+1;i++)
                {
                    if(i <count)
                        changeimg.setImageResource(img_path.get(i));
                    else
                        cnt=0;
                }
                cnt++;
            }
        });

    }
}