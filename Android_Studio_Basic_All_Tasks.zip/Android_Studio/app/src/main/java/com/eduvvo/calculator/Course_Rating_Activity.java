package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Toast;

public class Course_Rating_Activity extends AppCompatActivity {

    Button btnsubmitsuj;
    RadioButton rdbtnexc,rdbtngood,rdbtnok,rdbtnpoor;
    CheckBox chkccgood,chkeunderstand,chkenjoying,chkbooringlec;
    String rating="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_rating);

        rdbtnexc = findViewById(R.id.rdbtnexc);
        rdbtngood = findViewById(R.id.rdbtngood);
        rdbtnok = findViewById(R.id.rdbtnok);
        rdbtnpoor = findViewById(R.id.rdbtnpoor);

        chkccgood = findViewById(R.id.chkccgood);
        chkeunderstand = findViewById(R.id.chkeunderstand);
        chkenjoying = findViewById(R.id.chkenjoying);
        chkbooringlec = findViewById(R.id.chkbooringlec);

        btnsubmitsuj = findViewById(R.id.btnsubmitsuj);

        rdbtnexc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rdbtnexc.isChecked())
                    rating=rdbtnexc.getText().toString();
            }
        });
        rdbtngood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rdbtngood.isChecked())
                    rating=rdbtngood.getText().toString();
            }
        });
        rdbtnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rdbtnok.isChecked())
                    rating=rdbtnok.getText().toString();
            }
        });
        rdbtnpoor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rdbtnpoor.isChecked())
                    rating=rdbtnpoor.getText().toString();
            }
        });

        btnsubmitsuj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(Course_Rating_Activity.this,rating,Toast.LENGTH_SHORT).show();
                if(chkccgood.isChecked())
                    Toast.makeText(Course_Rating_Activity.this,rating+" and "+chkccgood.getText().toString(),Toast.LENGTH_SHORT).show();
                if(chkeunderstand.isChecked())
                    Toast.makeText(Course_Rating_Activity.this,rating+" and "+chkeunderstand.getText().toString(),Toast.LENGTH_SHORT).show();

                if(chkenjoying.isChecked())
                    Toast.makeText(Course_Rating_Activity.this,rating+" and "+chkenjoying.getText().toString(),Toast.LENGTH_SHORT).show();
                if(chkbooringlec.isChecked())
                    Toast.makeText(Course_Rating_Activity.this,rating+" and "+chkbooringlec.getText().toString(),Toast.LENGTH_SHORT).show();

            }
        });
    }
}