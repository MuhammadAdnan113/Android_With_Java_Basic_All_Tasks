package com.eduvvo.calculator;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SirTaskViewHolder extends RecyclerView.ViewHolder{
    TextView tv;
    public SirTaskViewHolder(@NonNull View itemView) {
        super(itemView);
        tv=itemView.findViewById(R.id.sirtaskrecyclerrow);
    }
}
