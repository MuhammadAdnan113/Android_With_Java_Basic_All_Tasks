package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Gift_Activity extends AppCompatActivity {

    Button btngift;
    EditText txtname,txtemail,txtphone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gift);

        btngift=findViewById(R.id.btngift);

        txtname=findViewById(R.id.txtname);
        txtemail=findViewById(R.id.txtemail);
        txtphone=findViewById(R.id.txtphone);

        btngift.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=txtname.getText().toString();
                String email=txtemail.getText().toString();
                String phone=txtphone.getText().toString();

                Intent intent=new Intent(Gift_Activity.this,Recieve_Activity.class);
                intent.putExtra("Name",name);
                intent.putExtra("Email",email);
                intent.putExtra("Phone",phone);
                startActivity(intent);
            }
        });
    }
}