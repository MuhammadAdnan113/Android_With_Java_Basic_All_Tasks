package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SyncStatusObserver;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class Home_Activity extends AppCompatActivity {

    Button btncalc,btnchkbox,btnradio,btncase,btngift,btnmore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btncalc=findViewById(R.id.btncalc);
        btnchkbox=findViewById(R.id.btnchkbox);
        btnradio=findViewById(R.id.btnradio);
        btncase=findViewById(R.id.btncase);
        btngift=findViewById(R.id.btngift);
        btnmore=findViewById(R.id.btnmore);

        btncalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Home_Activity.this,Calculator_Activity.class);
                startActivity(intent);
            }
        }); //end btncalc

        btnchkbox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Home_Activity.this,CheckBox_Activity.class);
                startActivity(intent);
            }
        }); // end btnchkbox

        btnradio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Home_Activity.this,Radio_Activity.class);
                startActivity(intent);
            }
        }); // end btnradio

        btncase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Home_Activity.this,CaseChange_Activity.class);
                startActivity(intent);
            }
        }); // end btncase

        btngift.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Home_Activity.this,Gift_Activity.class);
                startActivity(intent);
            }
        }); // end btncase

        btnmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Home_Activity.this,More_Activity.class);
                startActivity(intent);
            }
        }); // end btnbill

    }
}