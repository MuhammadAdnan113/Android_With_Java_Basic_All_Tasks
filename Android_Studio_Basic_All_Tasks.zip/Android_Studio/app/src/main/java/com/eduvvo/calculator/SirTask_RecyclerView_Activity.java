package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class SirTask_RecyclerView_Activity extends AppCompatActivity {

    RecyclerView taskrecyclerview;
    ArrayList<Employee> elist = new ArrayList<Employee>();
    Employee obj = new Employee();
    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sir_task_recycler_view);

        obj.id=123;
        obj.name="Adnan";
        obj.salary=20000;
        obj.taxpay=2000;
        elist.add(obj);

        taskrecyclerview = findViewById(R.id.taskrecyclerview);

        SirTaskRecyclerViewAdapter adapter = new SirTaskRecyclerViewAdapter(elist);
        taskrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        taskrecyclerview.setAdapter(adapter);

    }
}