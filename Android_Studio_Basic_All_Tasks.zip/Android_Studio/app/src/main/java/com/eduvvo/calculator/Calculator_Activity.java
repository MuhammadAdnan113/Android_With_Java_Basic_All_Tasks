package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Calculator_Activity extends AppCompatActivity {

    Button btnadd,btnsub,btnmul,btndiv;
    EditText etxtv1,etxtv2;
    TextView etxtres;
    Button btnhome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        etxtv1=findViewById(R.id.etxtv1);
        etxtv2=findViewById(R.id.etxtv2);

        btnadd=findViewById(R.id.btnadd);
        btnsub=findViewById(R.id.btnsub);
        btnmul=findViewById(R.id.btnmul);
        btndiv=findViewById(R.id.btndiv);

        etxtres=findViewById(R.id.etxtres);

        btnhome=findViewById(R.id.btnhome);
    btnadd.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            if (!(etxtv2.getText().toString().isEmpty())
                || !(etxtv1.getText().toString().isEmpty())) {
              double value1 = Double.parseDouble(etxtv1.getText().toString());
              double value2 = Double.parseDouble(etxtv2.getText().toString());
              double res = value1 + value2;
              etxtres.setText("Result: " + res + "");
              Toast.makeText(Calculator_Activity.this, "Button Add", Toast.LENGTH_SHORT).show();
            }
          }
        });

        btnsub.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!(etxtv2.getText().toString().isEmpty()) || !(etxtv1.getText().toString().isEmpty())) {
                            double value1 = Double.parseDouble(etxtv1.getText().toString());
                            double value2 = Double.parseDouble(etxtv2.getText().toString());
                            double res = value1 - value2;
                            etxtres.setText("Result: " + res + "");
                        }
                    }
                });

        btnmul.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!(etxtv2.getText().toString().isEmpty()) || !(etxtv1.getText().toString().isEmpty())) {
                            double value1 = Double.parseDouble(etxtv1.getText().toString());
                            double value2 = Double.parseDouble(etxtv2.getText().toString());
                            double res = value1 * value2;
                            etxtres.setText("Result: " + res + "");
                        }
                    }
                });

        btndiv.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!(etxtv2.getText().toString().isEmpty()) || !(etxtv1.getText().toString().isEmpty())) {
                            double value1 = Double.parseDouble(etxtv1.getText().toString());
                            double value2 = Double.parseDouble(etxtv2.getText().toString());
                            if (value2==0)
                                value2=1;
                            double res = value1 / value2;
                            etxtres.setText("Result: " + res + "");
                        }
                    }
                });


        btnhome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(Calculator_Activity.this,Home_Activity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}