package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class More_Activity extends AppCompatActivity {

    Button btnbill,btnspin,custspin,btnimgchange,btnrecyclerview,btnsirtask,btnsqlite,
            btnRatingcourse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more);

        btnbill=findViewById(R.id.btnbill);
        btnspin=findViewById(R.id.btnspin);
        custspin=findViewById(R.id.btncustspin);
        btnimgchange=findViewById(R.id.btnimgchange);
        btnrecyclerview=findViewById(R.id.btnrecyclerview);
        btnsirtask=findViewById(R.id.btnsirtask);
        btnsqlite=findViewById(R.id.btnsqlite);
        btnRatingcourse=findViewById(R.id.btnRatingcourse);

        btnbill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(More_Activity.this,Bill_Activity.class);
                startActivity(intent);
            }
        }); // end btnbill

        btnspin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(More_Activity.this,Spinner_Activity.class);
                startActivity(intent);
            }
        }); // end btnspin

        custspin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(More_Activity.this,Custom_Stinner.class);
                startActivity(intent);
            }
        }); // end custspin

        btnimgchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(More_Activity.this,Image_Changer_Activity.class);
                startActivity(intent);
            }
        }); // end btnimgchange

        btnrecyclerview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(More_Activity.this,RecyclerView_Activity.class);
                startActivity(intent);
            }
        }); // end btnimgchange

        btnsirtask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(More_Activity.this,SirTask_Activity.class);
                startActivity(intent);
            }
        }); // end btnsirtask

        btnsqlite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(More_Activity.this,SqlLite_Example_Activity.class);
                startActivity(intent);
            }
        }); // end btnsqlite

        btnRatingcourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(More_Activity.this,Course_Rating_Activity.class);
                startActivity(intent);
            }
        }); // end btnRatingcourse

    }
}