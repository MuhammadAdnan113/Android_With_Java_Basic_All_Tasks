package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

public class SqlLite_Example_Activity extends AppCompatActivity {

    EditText etxtstdid,etxtstdname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sql_lite_example);
    }
}