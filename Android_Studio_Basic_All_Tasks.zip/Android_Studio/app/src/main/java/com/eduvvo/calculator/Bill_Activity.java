package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Bill_Activity extends AppCompatActivity {

    Button btnbillcalc;
    EditText etxtid,etxtname,etxtcunits,etxtcbill,etxttax,etxttbill;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill);

        btnbillcalc=findViewById(R.id.btnbillcalc);

        etxtid=findViewById(R.id.etxtid);
        etxtname=findViewById(R.id.etxtname);
        etxtcunits=findViewById(R.id.etxtcunits);

        etxtcbill=findViewById(R.id.etxtcbill);
        etxttax=findViewById(R.id.etxttax);
        etxttbill=findViewById(R.id.etxttbill);

    btnbillcalc.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            String id = etxtid.getText().toString();
            String name = etxtname.getText().toString();
            double consumedunits = Double.parseDouble(etxtcunits.getText().toString());
            if (consumedunits >= 0 && consumedunits <= 99.0) {
                etxtcbill.setText(consumedunits + "");
                etxttax.setText("0");
                etxttbill.setText((consumedunits * 2.0) + "");
            }

            if (consumedunits >= 100 && consumedunits <= 199) {
                etxtcbill.setText(consumedunits + "");
                etxttax.setText("0");
                etxttbill.setText((consumedunits * 2.5) + "");
            }

            if (consumedunits >199 && consumedunits <= 499) {
                etxtcbill.setText(consumedunits + "");
                etxttax.setText("0");
                etxttbill.setText((consumedunits * 4.0) + "");
            }

            if (consumedunits >499){
                etxtcbill.setText(consumedunits + "");
                etxttax.setText("500");
                etxttbill.setText(((consumedunits * 4.0)*1.5) + "");
            }
          }
        });
    }
}