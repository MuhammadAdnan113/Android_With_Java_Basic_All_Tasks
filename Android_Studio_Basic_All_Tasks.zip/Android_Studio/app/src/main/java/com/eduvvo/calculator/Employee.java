package com.eduvvo.calculator;

import java.util.ArrayList;

public class Employee {
    int id,salary,taxpay;
    String name;

    ArrayList<Employee> elist = new ArrayList<Employee>();

}
