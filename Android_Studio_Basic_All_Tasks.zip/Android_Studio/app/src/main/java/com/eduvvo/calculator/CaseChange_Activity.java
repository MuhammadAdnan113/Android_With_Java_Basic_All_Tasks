package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Locale;

public class CaseChange_Activity extends AppCompatActivity {

    Button btnlower,btnupper,btnhome1;
    EditText etxtname;
    TextView lblres1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_change);

        btnlower=findViewById(R.id.btnlower);
        btnupper=findViewById(R.id.btnupper);
        etxtname=findViewById(R.id.etxtname);
        btnhome1=findViewById(R.id.btnhome1);
        lblres1=findViewById(R.id.lblres1);



        btnlower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(etxtname.getText().toString().isEmpty())){
                String name=etxtname.getText().toString();
                lblres1.setText(""+name.toLowerCase());
            }
            else
                lblres1.setText("Enter Full Name");
            }
        });

    btnupper.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            if (!(etxtname.getText().toString().isEmpty())) {
              String name = etxtname.getText().toString();
              lblres1.setText("" + name.toUpperCase());
            }
            else {lblres1.setText("Enter Full Name");}
          }
        });

        btnhome1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(CaseChange_Activity.this,Home_Activity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}