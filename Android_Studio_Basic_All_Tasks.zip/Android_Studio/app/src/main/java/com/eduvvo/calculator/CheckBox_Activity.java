package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class CheckBox_Activity extends AppCompatActivity {

    CheckBox chkcricket,chkhockey,chkpubg;
    Button btnshow,btngohome;
    TextView lblres,lblshow;
    int count=0;
    String crk="",hck="",pubg="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_box);

        chkcricket=findViewById(R.id.chkcricket);
        chkhockey=findViewById(R.id.chkhockey);
        chkpubg=findViewById(R.id.chkpubg);
        btnshow=findViewById(R.id.btnshow);
        btngohome=findViewById(R.id.btngohome);
        lblres=findViewById(R.id.lblres);
        lblshow=findViewById(R.id.lblshow);

        lblres.setText("You Selected " + count + " Items");

    chkcricket.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            if (chkcricket.isChecked()) {
              count++;
                crk="Cricket";
            } else {
                count--;
                crk="";
            }
            lblres.setText("You Selected " + count + " Items");
          }
        });

    chkhockey.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            if (chkhockey.isChecked()) {
              count++;
              hck = "Hockey";
            } else {
              count--;
              hck = "";
            }
            lblres.setText("You Selected " + count + " Items");
          }
        });

    chkpubg.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            if (chkpubg.isChecked()) {
              count++;
              pubg = "PUBG";
            } else {
              count--;
              pubg="";
            }
            lblres.setText("You Selected " + count + " Items");
          }
        });

        btnshow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int total=0;
                if (chkcricket.isChecked())
                    total++;
                if (chkhockey.isChecked())
                    total++;
                if (chkpubg.isChecked())
                    total++;
                lblres.setText("You Selected "+total+" Items");
                if (crk.isEmpty() && hck.isEmpty() && pubg.isEmpty())
                    lblshow.setText("You Selected Nothing");
                else
                    lblshow.setText("Items are \n"+crk+" "+hck+" "+pubg);
            }
        });

        btngohome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(CheckBox_Activity.this,Home_Activity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}