package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class SirTask_Activity extends AppCompatActivity {
    EditText etxtid;
    Button btnlogin;
    ArrayList<Employee> elist = new ArrayList<Employee>();
    Employee obj = new Employee();
    int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sir_task);

        etxtid = findViewById(R.id.etxtid);
        btnlogin = findViewById(R.id.btnlogin);



        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id= Integer.parseInt(String.valueOf((etxtid.getText())));
                Intent intent= new Intent(SirTask_Activity.this,SirTask_RecyclerView_Activity.class);
                intent.putExtra("ID",id);
                startActivity(intent);
            }
        });

    }
}