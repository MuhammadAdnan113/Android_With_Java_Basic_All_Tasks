package com.eduvvo.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Recieve_Activity extends AppCompatActivity {

    TextView tvname,tvemail,tvphone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recieve);

        tvname=findViewById(R.id.tvname);
        tvemail=findViewById(R.id.tvemail);
        tvphone=findViewById(R.id.tvphone);

        Intent intent= getIntent();
        String name=intent.getStringExtra("Name");
        String email=intent.getStringExtra("Email");
        String phone=intent.getStringExtra("Phone");

        tvname.setText(name);
        tvemail.setText(email);
        tvphone.setText(phone);

    }
}